from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.api.routes import auth, quiz, student, educator
from starlette.middleware.sessions import SessionMiddleware
import os
app = FastAPI(title="EduTutor AI")
secret_key = os.getenv("SESSION_SECRET_KEY")

# Add session middleware (REQUIRED for request.session)
app.add_middleware(SessionMiddleware, secret_key="your-secret-key") 


# Mount static files (css, favicon, etc.)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Templates folder
templates = Jinja2Templates(directory="app/templates")
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # Render base.html with a message to show on the page
    return templates.TemplateResponse("base.html", {"request": request, "message": "Welcome to EduTutor AI!"})
# Include auth and other routers
app.include_router(auth.router, prefix="/auth")
app.include_router(quiz.router, prefix="/quiz")
app.include_router(student.router, prefix="/student")
app.include_router(educator.router, prefix="/educator")


